/**
 * @file course.h
 * @author Nojus Niuklys  
 * @brief Header file for the course.c file. This contains the 'Course' struct as well as function declerations
 * @version 1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
/**
 * @brief This is a struct representing a course in university/highschool. This struct contains the name and the code of the course, an array of the students of the course (students of the course are defined with the 'Student' struct), and the total number of students
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
 * @brief These are all the function declerations for the 'Course' struct
 * 
 */
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


