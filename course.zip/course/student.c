/**
 * @file student.c
 * @author Nojus Niuklys
 * @brief This is a file which has functionality that corresponds to a student
 * @version 1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief This function adds a new grade to a Student stuct
 * 
 * @param student 
 * @param grade 
 */
void add_grade(Student* student, double grade)
{

  student->num_grades++;
  /**
   * @brief If this is the student's first grade then 'calloc' is used. If the student already has grades then the space is reallocated using 'realloc'
   * 
   */
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief This function returns a student's average
 * 
 * @param student (student struct)
 * @return double (student average)
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  /**
   * @brief The loop adds the student's grades and then the total divided by the number is returned
   * 
   */
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief This function prints out a student's information
 * 
 * @param student 
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  /**
   * @brief The loop iterates through the student's array of grades and prints each out
   * 
   */
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief This function generates a new student provided the number of grades that the student should have 
 * 
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  /**
   * @brief This loops initializes the id array with random characters
   * 
   */
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  /**
   * @brief This loop adds a random grade for all the grades that the student has (the number of grades that the student has was provided as a parameter to the function)
   * 
   */
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}