/**
 * @file student.h
 * @author Nojus Niuklys
 * @brief This is a header files for the student.c file. This contains 'Student' struct as well as function declerations
 * @version 1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */








/**
 * @brief This is a struct representing a student. It contains the student's full name, student id, an array of grades, and the size of the array of grades (how many courses the student has).
 * 
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/**
 * @brief These are all the function declerations for the 'Student' struct.
 * 
 */
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
